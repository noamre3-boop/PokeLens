#!/usr/bin/env python3
"""Builds app/src/main/assets/pokemon.tsv with every Pokemon (default forms)
and converts main-series base stats into Pokemon GO stats (GamePress formula).
Runs inside GitHub Actions before the APK build."""
import csv, io, math, os, sys, urllib.request

BASE = os.environ.get("POKEAPI_CSV", "https://raw.githubusercontent.com/PokeAPI/pokeapi/master/data/v2/csv/")
OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "assets", "pokemon.tsv")
MAX_ID = 1025

def load(name):
    if BASE.startswith("http"):
        with urllib.request.urlopen(BASE + name, timeout=60) as r:
            text = r.read().decode("utf-8")
    else:
        with open(os.path.join(BASE, name), encoding="utf-8") as f:
            text = f.read()
    return list(csv.DictReader(io.StringIO(text)))

def rnd(x):  # round half up like the game formulas
    return int(math.floor(x + 0.5))

CPM40 = 0.79030001

def go_stats(hp, atk, df, spa, spd, spe):
    speed_mod = 1 + (spe - 75) / 500
    a = rnd(rnd(2 * (7/8 * max(atk, spa) + 1/8 * min(atk, spa))) * speed_mod)
    d = rnd(rnd(2 * (5/8 * max(df, spd) + 3/8 * min(df, spd))) * speed_mod)
    s = int(math.floor(hp * 1.75 + 50))
    cp40 = math.floor((a + 15) * math.sqrt(d + 15) * math.sqrt(s + 15) * CPM40 ** 2 / 10)
    if cp40 > 4000:  # the "nerf" applied to very strong Pokemon
        a, d, s = rnd(a * 0.91), rnd(d * 0.91), rnd(s * 0.91)
    return a, d, s

def main():
    pokemon = [p for p in load("pokemon.csv") if p["is_default"] == "1" and int(p["id"]) <= MAX_ID]
    stats = {}
    for r in load("pokemon_stats.csv"):
        stats.setdefault(r["pokemon_id"], {})[int(r["stat_id"])] = int(r["base_stat"])
    types = {t["id"]: t["identifier"] for t in load("types.csv")}
    ptypes = {}
    for r in load("pokemon_types.csv"):
        ptypes.setdefault(r["pokemon_id"], {})[int(r["slot"])] = types[r["type_id"]]
    names = {r["pokemon_species_id"]: r["name"] for r in load("pokemon_species_names.csv") if r["local_language_id"] == "9"}
    rows = []
    for p in pokemon:
        pid = p["id"]
        st = stats[pid]
        a, d, s = go_stats(st[1], st[2], st[3], st[4], st[5], st[6])
        t = ptypes.get(pid, {})
        name = names.get(p["species_id"], p["identifier"].replace("-", " ").title())
        rows.append((int(pid), name, t.get(1, "normal"), t.get(2, ""), a, d, s))
    rows.sort()
    if len(rows) < 100:
        sys.exit("Too few Pokemon downloaded: %d" % len(rows))
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        for r in rows:
            f.write("\t".join(str(x) for x in r) + "\n")
    print("Wrote %d Pokemon to %s" % (len(rows), OUT))

if __name__ == "__main__":
    main()

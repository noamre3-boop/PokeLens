package com.noam.pokescan.core;

public final class PokeEntry {
    public final int id;
    public final String name, type1, type2, key;
    public final int atk, def, sta;

    public PokeEntry(int id, String name, String type1, String type2, int atk, int def, int sta) {
        this.id = id; this.name = name; this.type1 = type1; this.type2 = type2;
        this.atk = atk; this.def = def; this.sta = sta;
        this.key = PokeDb.norm(name);
    }
}

package com.noam.pokescan.core;

import java.util.*;

/** CP / HP formulas and IV solving like Pokemon GO. */
public final class IvCalc {
    // CP multiplier for levels 1, 1.5, 2 ... 50 (index = (level-1)*2)
    public static final double[] CPM = {
            0.094, 0.1351374318, 0.16639787, 0.192650919, 0.21573247, 0.2365726613, 0.25572005, 0.2735303812,
            0.29024988, 0.3060573775, 0.3210876, 0.3354450362, 0.34921268, 0.3624577511, 0.3752356, 0.387592416,
            0.39956728, 0.4111935514, 0.42250001, 0.4329264091, 0.44310755, 0.4530599591, 0.46279839, 0.472336093,
            0.48168495, 0.4908558003, 0.49985844, 0.508701765, 0.51739395, 0.5259425113, 0.53435433, 0.5426357375,
            0.55079269, 0.5588305862, 0.56675452, 0.5745691333, 0.58227891, 0.5898879072, 0.59740001, 0.6048236651,
            0.61215729, 0.6194041216, 0.62656713, 0.6336491432, 0.64065295, 0.6475809666, 0.65443563, 0.6612192524,
            0.667934, 0.6745818959, 0.68116492, 0.6876849038, 0.69414365, 0.7005566937, 0.70688421, 0.7131668064,
            0.71937198, 0.7255387059, 0.73163998, 0.7347410093, 0.73776948, 0.7407855938, 0.74378943, 0.7467812109,
            0.74976104, 0.7527290867, 0.75568551, 0.7586303683, 0.76156384, 0.7644860647, 0.76739717, 0.7702972656,
            0.7731865, 0.7760649616, 0.77893275, 0.7817900548, 0.78463697, 0.7874736075, 0.79030001, 0.792803968,
            0.79530001, 0.797800015, 0.8003, 0.802799995, 0.8053, 0.8078, 0.81029999, 0.812799985,
            0.81529999, 0.81779999, 0.82029999, 0.82279999, 0.82529999, 0.82779999, 0.83029999, 0.83279999,
            0.83529999, 0.83779999, 0.84029999};
    static final int[] DUST = {200, 400, 600, 800, 1000, 1300, 1600, 1900, 2200, 2500, 3000, 3500, 4000, 4500,
            5000, 6000, 7000, 8000, 9000, 10000, 11000, 12000, 13000, 14000, 15000};

    public static double cpm(double level) { return CPM[(int) Math.round((level - 1) * 2)]; }

    public static int cp(PokeEntry e, int ia, int id, int is, double level) {
        double m = cpm(level);
        return Math.max(10, (int) Math.floor((e.atk + ia) * Math.sqrt(e.def + id) * Math.sqrt(e.sta + is) * m * m / 10));
    }

    public static int hp(PokeEntry e, int is, double level) {
        return Math.max(10, (int) Math.floor((e.sta + is) * cpm(level)));
    }

    /** Base stardust cost to power up from this level (levels 1..49.5). */
    public static int dustCost(double level) {
        int band = (int) Math.floor((level - 1) / 2);
        return band < DUST.length ? DUST[band] : -1;
    }

    public static boolean isDustValue(int v) {
        for (double lv = 1; lv < 50; lv += 0.5) {
            int b = dustCost(lv);
            if (v == b || v == Math.round(b * 1.2) || v == Math.round(b * 0.9) || v == Math.round(b * 0.5)) return true;
        }
        return false;
    }

    public static final class Combo {
        public final double level; public final int a, d, s; public final String mod;
        Combo(double level, int a, int d, int s, String mod) { this.level = level; this.a = a; this.d = d; this.s = s; this.mod = mod; }
        public int pct() { return (int) Math.round((a + d + s) * 100.0 / 45); }
    }

    /**
     * @param hp   -1 if unknown
     * @param dust -1 if unknown
     * @param wild true = wild encounter (whole levels 1..35), false = own Pokemon (half levels 1..50)
     */
    public static List<Combo> solve(PokeEntry e, int cp, int hp, int dust, boolean wild) {
        List<Combo> out = new ArrayList<>();
        double step = wild ? 1 : 0.5, maxLv = wild ? 35 : 50;
        for (double lv = 1; lv <= maxLv; lv += step) {
            String mod = "";
            if (dust > 0) {
                int b = dustCost(lv);
                if (b < 0) continue;
                if (dust == b) mod = "";
                else if (dust == Math.round(b * 1.2)) mod = "צל";
                else if (dust == Math.round(b * 0.9)) mod = "מטוהר";
                else if (dust == Math.round(b * 0.5)) mod = "מזל";
                else continue;
            }
            for (int s = 0; s <= 15; s++) {
                if (hp > 0 && hp(e, s, lv) != hp) continue;
                for (int a = 0; a <= 15; a++)
                    for (int d = 0; d <= 15; d++)
                        if (cp(e, a, d, s, lv) == cp) out.add(new Combo(lv, a, d, s, mod));
            }
        }
        return out;
    }
}

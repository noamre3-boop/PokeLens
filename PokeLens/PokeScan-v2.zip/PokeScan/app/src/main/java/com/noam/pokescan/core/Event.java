package com.noam.pokescan.core;

/** One log entry. type: E = encounter seen, C = caught, F = fled/ran. */
public final class Event {
    public long time;
    public char type;
    public int id, cp, ivMin = -1, ivMax = -1;
    public String name;
    public boolean shiny;

    public Event(long time, char type, int id, String name, int cp, int ivMin, int ivMax, boolean shiny) {
        this.time = time; this.type = type; this.id = id; this.name = name; this.cp = cp;
        this.ivMin = ivMin; this.ivMax = ivMax; this.shiny = shiny;
    }

    public String toLine() {
        return time + "\t" + type + "\t" + id + "\t" + name.replace('\t', ' ') + "\t" + cp + "\t" + ivMin + "\t" + ivMax + "\t" + (shiny ? 1 : 0);
    }

    public static Event parse(String l) {
        String[] p = l.split("\t", -1);
        if (p.length < 8 || p[1].isEmpty()) return null;
        try {
            return new Event(Long.parseLong(p[0]), p[1].charAt(0), Integer.parseInt(p[2]), p[3],
                    Integer.parseInt(p[4]), Integer.parseInt(p[5]), Integer.parseInt(p[6]), "1".equals(p[7]));
        } catch (NumberFormatException e) { return null; }
    }

    public String ivText() {
        if (ivMin < 0) return "?";
        return ivMin == ivMax ? ivMin + "%" : ivMin + "–" + ivMax + "%";
    }
}

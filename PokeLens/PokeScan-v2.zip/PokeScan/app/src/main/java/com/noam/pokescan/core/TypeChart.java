package com.noam.pokescan.core;

import java.util.*;

/** Pokemon GO type effectiveness (1.6 / 0.625 / 0.390625). */
public final class TypeChart {
    public static final String[] TYPES = {"normal","fire","water","electric","grass","ice","fighting","poison","ground",
            "flying","psychic","bug","rock","ghost","dragon","dark","steel","fairy"};
    public static final String[] HE = {"נורמלי","אש","מים","חשמל","עשב","קרח","לחימה","רעל","אדמה",
            "מעופף","על-חושי","חרק","סלע","רוח","דרקון","אופל","פלדה","פיה"};
    // row = attacking type, column = defending type. s=super, n=not very, x=immune (GO: double resist)
    static final String[] ROWS = {
            "............nx..n.", // normal
            ".nn.ss.....sn.n.s.", // fire
            ".sn.n...s...s.n...", // water
            "..snn...xs....n...", // electric
            ".ns.n..nsn.ns.n.n.", // grass
            ".nn.sn..ss....s.n.", // ice
            "s....s.n.nnnsx.ssn", // fighting
            "....s..nn...nn..xs", // poison
            ".s.sn..s.x.ns...s.", // ground
            "...ns.s....sn...n.", // flying
            "......ss..n....xn.", // psychic
            ".n..s.nn.ns..n.snn", // bug
            ".s...sn.ns.s....n.", // rock
            "x.........s..s.n..", // ghost
            "..............s.nx", // dragon
            "......n...s..s.n.n", // dark
            ".nnn.s......s...ns", // steel
            ".n....sn......ssn.", // fairy
    };

    public static int index(String t) {
        for (int i = 0; i < TYPES.length; i++) if (TYPES[i].equals(t)) return i;
        return -1;
    }

    public static String he(String t) {
        int i = index(t);
        return i < 0 ? t : HE[i];
    }

    static double mult(char c) {
        switch (c) { case 's': return 1.6; case 'n': return 0.625; case 'x': return 0.390625; default: return 1.0; }
    }

    /** Damage multiplier of each attacking type against the given defender types. */
    public static double[] defense(String t1, String t2) {
        double[] m = new double[TYPES.length];
        int a = index(t1), b = t2 == null || t2.isEmpty() ? -1 : index(t2);
        for (int i = 0; i < TYPES.length; i++) {
            double v = 1;
            if (a >= 0) v *= mult(ROWS[i].charAt(a));
            if (b >= 0) v *= mult(ROWS[i].charAt(b));
            m[i] = v;
        }
        return m;
    }
}

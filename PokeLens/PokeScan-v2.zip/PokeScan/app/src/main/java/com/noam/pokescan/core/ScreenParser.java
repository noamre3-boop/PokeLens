package com.noam.pokescan.core;

import java.util.*;
import java.util.regex.*;

/** Turns OCR lines from a Pokemon GO screenshot into structured data. Read-only: never touches the game. */
public final class ScreenParser {
    public static final class Result {
        public PokeEntry pokemon;
        public String nameLine;
        public int cp = -1, hp = -1, hpMax = -1, dust = -1;
        public boolean ownScreen; // true = Pokemon details screen, false = wild encounter
        public boolean fled, gotcha;
        public int cpCount;       // how many "CP ###" labels were seen (many = storage list)
        public boolean isList() { return cpCount > 2; }
        public boolean isWild() { return pokemon != null && !ownScreen && !isList() && cp > 0; }
        public boolean isOwn() { return pokemon != null && ownScreen && cp > 0; }
    }

    static final Pattern CP = Pattern.compile("(?i)(?:^|[^a-z])c\\s*p\\s*[:.]?\\s*([0-9oO]{2,5})\\b");
    static final Pattern HP1 = Pattern.compile("(?i)(\\d{1,3})\\s*/\\s*(\\d{1,3})\\s*h\\s*p");
    static final Pattern HP2 = Pattern.compile("(?i)h\\s*p\\s*(\\d{1,3})\\s*/\\s*(\\d{1,3})");
    static final Pattern NUM = Pattern.compile("^[\\s\\d,.]+$");
    static final Set<String> UI_WORDS = new HashSet<>(Arrays.asList(
            "weight", "height", "stardust", "candy", "powerup", "evolve", "appraise", "transfer", "favorite",
            "attack", "defense", "hp", "trade", "run", "items", "pokemon", "berries", "pokeball", "caught", "gotcha", "fled"));

    public static Result parse(List<String> lines, PokeDb db) {
        Result r = new Result();
        for (String l : lines) {
            String n = PokeDb.norm(l);
            if (n.contains("fled")) r.fled = true;
            if (n.contains("gotcha")) r.gotcha = true;
            Matcher cm = CP.matcher(l);
            while (cm.find()) {
                r.cpCount++;
                if (r.cp < 0) {
                    try { r.cp = Integer.parseInt(cm.group(1).replace('o', '0').replace('O', '0')); } catch (NumberFormatException ignored) {}
                }
            }
            if (r.hp < 0) {
                Matcher m = HP1.matcher(l);
                if (!m.find()) { m = HP2.matcher(l); if (!m.find()) m = null; }
                if (m != null) { r.hp = Integer.parseInt(m.group(1)); r.hpMax = Integer.parseInt(m.group(2)); }
            }
        }
        // stardust: first plain number after "POWER UP" that is a real stardust cost
        for (int i = 0; i < lines.size() && r.dust < 0; i++) {
            if (!PokeDb.norm(lines.get(i)).contains("powerup")) continue;
            for (int j = i; j < Math.min(lines.size(), i + 5); j++) {
                String t = lines.get(j).replaceAll("(?i)power\\s*up", " ").trim();
                for (String tok : t.split("\\s+")) {
                    tok = tok.replaceAll("[,.]", "");
                    if (!tok.matches("\\d{3,5}")) continue;
                    int v = Integer.parseInt(tok);
                    if (IvCalc.isDustValue(v)) { r.dust = v; break; }
                }
                if (r.dust > 0) break;
            }
        }
        // Pokemon name: whole line first, then each word (e.g. "Pikachu CP 312")
        for (String l : lines) {
            String clean = l.replaceAll("(?i)c\\s*p\\s*[:.]?\\s*\\d+", " ").trim();
            if (UI_WORDS.contains(PokeDb.norm(clean))) continue;
            PokeEntry e = db.find(clean);
            if (e == null) {
                for (String w : clean.split("\\s+")) {
                    if (UI_WORDS.contains(PokeDb.norm(w))) continue;
                    e = db.find(w);
                    if (e != null) break;
                }
            }
            if (e != null) { r.pokemon = e; r.nameLine = l; break; }
        }
        r.ownScreen = r.hpMax > 0;
        return r;
    }
}

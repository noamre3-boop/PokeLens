package com.noam.pokescan;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import com.noam.pokescan.core.*;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    static final int REQ_CAPTURE = 7, REQ_EXPORT = 8;
    static PokeDb db;

    TextView status;
    FrameLayout content;
    final Button[] tabs = new Button[4];
    int tab = 0;
    long shownVersion = -1;
    final Handler h = new Handler(Looper.getMainLooper());
    final Runnable poll = new Runnable() {
        @Override public void run() {
            refreshStatus();
            if ((tab == 0 || tab == 2) && Store.log(MainActivity.this).version() != shownVersion) showTab(tab);
            h.postDelayed(this, 2000);
        }
    };

    static PokeDb db(android.content.Context c) {
        if (db == null) {
            try { db = new PokeDb(c.getAssets().open("pokemon.tsv")); }
            catch (Exception e) { throw new RuntimeException("pokemon.tsv missing – run tools/build_data.py", e); }
        }
        return db;
    }

    int dp(float v) { return Ui.dp(this, v); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(dp(14), dp(26), dp(14), 0);

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = Ui.text(this, "PokeScan", 26, Ui.ACCENT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        status = Ui.text(this, "", 12, Ui.TEXT);
        head.addView(status);
        root.addView(head);

        LinearLayout tabRow = new LinearLayout(this);
        String[] names = {"📊 דשבורד", "🔍 סורק", "📜 יומן", "⚙️ הגדרות"};
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            Button t = Ui.button(this, names[i], Ui.CARD);
            t.setTextSize(13);
            t.setOnClickListener(v -> showTab(idx));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1);
            lp.setMargins(dp(3), dp(10), dp(3), dp(8));
            tabRow.addView(t, lp);
            tabs[i] = t;
        }
        root.addView(tabRow);

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(root);
        db(this);
        showTab(Settings.canDrawOverlays(this) ? 0 : 1);
    }

    @Override protected void onResume() { super.onResume(); h.post(poll); }
    @Override protected void onPause() { super.onPause(); h.removeCallbacks(poll); }

    void showTab(int i) {
        tab = i;
        for (int k = 0; k < 4; k++) {
            tabs[k].setBackground(Ui.round(k == i ? Ui.ACCENT : Ui.CARD, 12, this));
            tabs[k].setTextColor(k == i ? 0xFF000000 : 0xFFFFFFFF);
        }
        content.removeAllViews();
        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, 0, 0, dp(30));
        sv.addView(col);
        content.addView(sv);
        shownVersion = Store.log(this).version();
        switch (i) {
            case 0: buildDashboard(col); break;
            case 1: buildScanner(col); break;
            case 2: buildLog(col); break;
            default: buildSettings(col); break;
        }
    }

    // ───────────── helpers ─────────────
    TextView section(LinearLayout col, String s) {
        TextView t = Ui.text(this, s, 17, Ui.ACCENT);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(16), 0, dp(6));
        col.addView(t);
        return t;
    }

    LinearLayout card(LinearLayout col) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(12), dp(10), dp(12), dp(10));
        c.setBackground(Ui.round(Ui.CARD, 16, this));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(8);
        col.addView(c, lp);
        return c;
    }

    void button(LinearLayout col, String s, int color, View.OnClickListener l) {
        Button b = Ui.button(this, s, color);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        lp.topMargin = dp(8);
        col.addView(b, lp);
    }

    void tiles(LinearLayout col, String[][] items) {
        for (int i = 0; i < items.length; i += 2) {
            LinearLayout row = new LinearLayout(this);
            for (int k = i; k < Math.min(i + 2, items.length); k++) {
                LinearLayout t = new LinearLayout(this);
                t.setOrientation(LinearLayout.VERTICAL);
                t.setGravity(Gravity.CENTER);
                t.setPadding(dp(8), dp(12), dp(8), dp(12));
                t.setBackground(Ui.round(Ui.CARD, 16, this));
                TextView v = Ui.text(this, items[k][0], 24, 0xFFFFFFFF);
                v.setTypeface(Typeface.DEFAULT_BOLD);
                v.setGravity(Gravity.CENTER);
                TextView l = Ui.text(this, items[k][1], 12, 0xFFAFC0E0);
                l.setGravity(Gravity.CENTER);
                t.addView(v); t.addView(l);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
                lp.setMargins(dp(4), dp(4), dp(4), dp(4));
                row.addView(t, lp);
            }
            col.addView(row);
        }
    }

    void chart(LinearLayout col, String title, String[] labels, int[] values, int color) {
        section(col, title);
        LinearLayout c = card(col);
        BarChart ch = new BarChart(this, color);
        ch.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        ch.set(labels, values);
        c.addView(ch);
    }

    static String time(long t) { return new SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(new Date(t)); }

    // ───────────── dashboard ─────────────
    void buildDashboard(LinearLayout col) {
        EventLog log = Store.log(this);
        Stats s = Stats.of(log.all(), System.currentTimeMillis(), TimeZone.getDefault());
        if (s.caught + s.seen + s.fled == 0) {
            LinearLayout c = card(col);
            c.addView(Ui.text(this, "עוד אין נתונים.\n\nהפעל את הסורק בלשונית 🔍, פתח את Pokémon GO ושחק כרגיל. " +
                    "כל מפגש ותפיסה נרשמים לבד, והדשבורד מתמלא.\n\nשייני? לחץ ✨ בכרטיס הצף.", 15, Ui.TEXT));
        }
        section(col, "היום");
        tiles(col, new String[][]{
                {String.valueOf(s.todayCaught), "נתפסו היום"},
                {String.valueOf(s.todayShiny), "✨ שייני היום"},
                {String.valueOf(s.todaySeen), "מפגשים היום"},
                {s.streakDays + " 🔥", "ימים ברצף"},
        });
        section(col, "סה״כ");
        tiles(col, new String[][]{
                {String.valueOf(s.caught), "נתפסו"},
                {String.valueOf(s.shiny), "✨ שייני"},
                {String.valueOf(s.seen), "מפגשים"},
                {String.valueOf(s.fled), "ברחו"},
                {String.format(Locale.US, "%.0f%%", s.catchRate()), "אחוז תפיסה"},
                {s.shinyRate(), "יחס שייני"},
                {String.valueOf(s.hundos), "💯 מושלמים"},
                {String.valueOf(s.high), "IV 90%+"},
                {s.uniqueCaught + "/" + Stats.DEX_SIZE, String.format(Locale.US, "פוקידקס (%.1f%%)", s.dexPct())},
                {String.valueOf(s.avgCp), "CP ממוצע"},
        });
        if (s.bestCp > 0) tiles(col, new String[][]{{String.valueOf(s.bestCp), "CP הכי גבוה · " + s.bestCpName}});

        chart(col, "תפיסות ב-7 ימים", s.last7Labels, s.last7, Ui.ACCENT);
        chart(col, "התפלגות IV", new String[]{"<50", "50-79", "80-89", "90-99", "100"}, s.ivBuckets, 0xFF3DDC84);
        String[] hl = new String[24];
        for (int i = 0; i < 24; i++) hl[i] = String.valueOf(i);
        chart(col, "באיזו שעה אתה תופס", hl, s.hours, 0xFF5B8CFF);

        if (!s.shinies.isEmpty()) {
            section(col, "✨ השייני שלך");
            LinearLayout c = card(col);
            for (Event e : s.shinies) c.addView(Ui.text(this, "✨ " + e.name + " · CP " + e.cp + " · " + time(e.time), 14, Ui.TEXT));
        }
        if (!s.best.isEmpty()) {
            section(col, "🏆 ה-IV הכי גבוהים");
            LinearLayout c = card(col);
            for (Event e : s.best) c.addView(Ui.text(this, e.name + " · " + e.ivText() + " · CP " + e.cp + (e.shiny ? " ✨" : ""), 14, Ui.TEXT));
        }
        if (!s.topSpecies.isEmpty()) {
            section(col, "הכי נפוצים אצלך");
            LinearLayout c = card(col);
            for (Map.Entry<String, Integer> e : s.topSpecies) c.addView(Ui.text(this, e.getKey() + " × " + e.getValue(), 14, Ui.TEXT));
        }

        section(col, "פעולות");
        button(col, "✨ סמן תפיסה אחרונה כשייני", 0xFF7A4FD8, v -> {
            log.markLastCaughtShiny(true);
            toast("סומן ✨"); showTab(0);
        });
        button(col, "↩️ בטל רישום אחרון", Ui.BLUE, v -> {
            Event e = log.removeLast();
            toast(e == null ? "היומן ריק" : "בוטל: " + e.name); showTab(0);
        });
        button(col, "💾 ייצוא ל-CSV (Excel)", Ui.BLUE, v -> {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("text/csv").putExtra(Intent.EXTRA_TITLE, "pokescan.csv");
            startActivityForResult(i, REQ_EXPORT);
        });
        button(col, "🗑️ מחק את כל הנתונים", 0xFF8A2D3B, v -> new AlertDialog.Builder(this)
                .setMessage("למחוק את כל היומן והסטטיסטיקות?")
                .setPositiveButton("מחק", (d, w) -> { log.clear(); showTab(0); })
                .setNegativeButton("ביטול", null).show());
    }

    // ───────────── scanner ─────────────
    void buildScanner(LinearLayout col) {
        LinearLayout c = card(col);
        c.addView(Ui.text(this, "הסורק קורא את המסך בלבד ומציג מידע. הוא לא לוחץ, לא מתחבר לשרת ולא משנה את המשחק. כל פעולה במשחק אתה עושה בעצמך.", 14, Ui.TEXT));
        button(col, "1. אישור חלון צף", Ui.BLUE, v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()))));
        button(col, "2. הפעל סורק מסך", Ui.ACCENT, v -> startScan());
        button(col, "עצור סורק", 0xFF8A2D3B, v -> { stopService(new Intent(this, ScanService.class)); refreshStatus(); });

        section(col, "איך זה עובד");
        LinearLayout c2 = card(col);
        c2.addView(Ui.text(this,
                "• הסריקה האוטומטית פועלת כברירת מחדל (בועה ירוקה). לחיצה ארוכה מפעילה או מכבה אותה.\n" +
                "• לחיצה קצרה על הבועה: סריקה אחת עכשיו.\n" +
                "• במפגש בטבע: כרטיס עם המלצה (💎 חובה / ✅ כדאי / ➖ אפשר לוותר), התראה, ואם בחרת, גם הקראה קולית.\n" +
                "• אחרי תפיסה, כשמסך הפוקימון נפתח, התפיסה נרשמת לבד ביומן.\n" +
                "• שייני? לחץ ✨ בכרטיס. ברח? לחץ ✗. כינוי? 📋 מעתיק אותו, ואתה מדביק בעצמך.\n" +
                "• גרירת הבועה מזיזה אותה.", 14, Ui.TEXT));

        section(col, "חיפוש ידני (שם באנגלית או מספר)");
        EditText search = new EditText(this);
        search.setHint("Pikachu / 25");
        search.setTextColor(Ui.TEXT);
        search.setHintTextColor(0xFF6F7F9F);
        search.setSingleLine(true);
        col.addView(search);
        TextView info = Ui.text(this, "נטענו " + db(this).all.size() + " פוקימונים.", 15, Ui.TEXT);
        info.setTextIsSelectable(true);
        LinearLayout c3 = card(col);
        c3.addView(info);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int d) {}
            public void onTextChanged(CharSequence s, int a, int b, int d) {}
            public void afterTextChanged(Editable s) {
                List<PokeEntry> r = db(MainActivity.this).search(s.toString(), 8);
                if (r.isEmpty()) { info.setText(s.length() == 0 ? "" : "לא נמצא."); return; }
                StringBuilder b = new StringBuilder(InfoFormatter.basic(r.get(0)));
                Pvp.Info gl = Pvp.info(r.get(0), Pvp.GREAT, 0, 15, 15), ul = Pvp.info(r.get(0), Pvp.ULTRA, 0, 15, 15);
                if (gl != null) b.append("ליגה גדולה 0/15/15: מקום ").append(gl.rank).append(" · CP ").append(gl.cp).append('\n');
                if (ul != null) b.append("ליגה אולטרה 0/15/15: מקום ").append(ul.rank).append(" · CP ").append(ul.cp).append('\n');
                b.append(Store.log(MainActivity.this).hasCaught(r.get(0).id) ? "✓ כבר תפסת (לפי היומן)\n" : "○ עוד לא ביומן\n");
                if (r.size() > 1) {
                    b.append("\nעוד תוצאות: ");
                    for (int i = 1; i < r.size(); i++) b.append(i > 1 ? ", " : "").append(r.get(i).name);
                }
                info.setText(b);
            }
        });
    }

    // ───────────── log ─────────────
    void buildLog(LinearLayout col) {
        List<Event> all = Store.log(this).all();
        section(col, "יומן (" + all.size() + " רשומות)");
        if (all.isEmpty()) { card(col).addView(Ui.text(this, "ריק.", 14, Ui.TEXT)); return; }
        LinearLayout c = card(col);
        int shown = 0;
        for (int i = all.size() - 1; i >= 0 && shown < 200; i--, shown++) {
            Event e = all.get(i);
            String icon = e.type == 'C' ? (e.shiny ? "✨" : "✓") : e.type == 'F' ? "✗" : "👁";
            String what = e.type == 'C' ? "נתפס" : e.type == 'F' ? "ברח" : "נראה";
            TextView t = Ui.text(this, icon + " " + e.name + " · CP " + e.cp + " · IV " + e.ivText() + " · " + what + " · " + time(e.time), 14,
                    e.type == 'C' ? 0xFFFFFFFF : 0xFFAFC0E0);
            t.setPadding(0, dp(5), 0, dp(5));
            c.addView(t);
        }
    }

    // ───────────── settings ─────────────
    EditText numField(LinearLayout col, String label, int value) {
        col.addView(Ui.text(this, label, 14, Ui.TEXT));
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setText(String.valueOf(value));
        e.setTextColor(0xFFFFFFFF);
        col.addView(e);
        return e;
    }

    Switch sw(LinearLayout col, String label, boolean on) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextColor(Ui.TEXT);
        s.setChecked(on);
        s.setPadding(0, dp(8), 0, dp(8));
        col.addView(s);
        return s;
    }

    void buildSettings(LinearLayout col) {
        SharedPreferences p = Store.prefs(this);
        section(col, "חוקים להמלצה");
        LinearLayout c = card(col);
        EditText minIv = numField(c, "IV מינימלי ל-\"כדאי לתפוס\" (%)", p.getInt("minIv", 90));
        EditText pvp = numField(c, "דירוג PvP שנחשב טוב (מקום 1 עד...)", p.getInt("pvpTop", 20));
        Switch newSp = sw(c, "להמליץ לתפוס מין שעוד לא ביומן", p.getBoolean("newSpecies", true));
        c.addView(Ui.text(this, "רשימת מבוקשים (שמות באנגלית, מופרדים בפסיק). כשאחד מהם מופיע: 💎 והתראה חזקה", 14, Ui.TEXT));
        EditText watch = new EditText(this);
        watch.setText(p.getString("watch", ""));
        watch.setHint("Dratini, Larvitar, Gible");
        watch.setTextColor(0xFFFFFFFF);
        watch.setHintTextColor(0xFF6F7F9F);
        c.addView(watch);

        section(col, "התראות וסריקה");
        LinearLayout c2 = card(col);
        Switch vib = sw(c2, "רטט כשכדאי לתפוס", p.getBoolean("vibrate", true));
        Switch spk = sw(c2, "הקראה קולית (עברית)", p.getBoolean("speak", false));
        Switch all = sw(c2, "התראה על כל מפגש (לא רק כשכדאי)", p.getBoolean("notifyAll", false));
        Switch auto = sw(c2, "סריקה אוטומטית כשהסורק מופעל", p.getBoolean("autoStart", true));
        EditText interval = numField(c2, "כל כמה שניות לסרוק (1–10)", p.getInt("intervalSec", 2));

        button(col, "💾 שמור", Ui.ACCENT, v -> {
            p.edit()
                    .putInt("minIv", clamp(minIv, 0, 100, 90))
                    .putInt("pvpTop", clamp(pvp, 1, 4096, 20))
                    .putBoolean("newSpecies", newSp.isChecked())
                    .putString("watch", watch.getText().toString())
                    .putBoolean("vibrate", vib.isChecked())
                    .putBoolean("speak", spk.isChecked())
                    .putBoolean("notifyAll", all.isChecked())
                    .putBoolean("autoStart", auto.isChecked())
                    .putInt("intervalSec", clamp(interval, 1, 10, 2))
                    .apply();
            toast("נשמר ✓ (חל מיד)");
        });
    }

    static int clamp(EditText e, int lo, int hi, int def) {
        try { return Math.max(lo, Math.min(hi, Integer.parseInt(e.getText().toString().trim()))); }
        catch (NumberFormatException x) { return def; }
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    // ───────────── capture permission ─────────────
    void startScan() {
        if (!Settings.canDrawOverlays(this)) { toast("קודם אשר חלון צף (כפתור 1)"); return; }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_EXPORT) {
            if (res != RESULT_OK || data == null || data.getData() == null) return;
            try (OutputStream o = getContentResolver().openOutputStream(data.getData())) {
                o.write(Store.log(this).toCsv().getBytes(StandardCharsets.UTF_8));
                toast("נשמר ✓");
            } catch (Exception e) { toast("שגיאה בשמירה: " + e.getMessage()); }
            return;
        }
        if (req != REQ_CAPTURE) return;
        if (res != RESULT_OK || data == null) { toast("צריך לאשר צילום מסך כדי לסרוק"); return; }
        Intent i = new Intent(this, ScanService.class)
                .putExtra(ScanService.EXTRA_CODE, res)
                .putExtra(ScanService.EXTRA_DATA, data);
        startForegroundService(i);
        toast("הסורק פועל – עבור ל-Pokémon GO");
        refreshStatus();
    }

    void refreshStatus() {
        String o = Settings.canDrawOverlays(this) ? "✓ חלון צף" : "✗ חלון צף";
        String s = ScanService.running ? "🟢 סורק פועל" : "⚪ סורק כבוי";
        status.setText(s + "\n" + o);
    }
}

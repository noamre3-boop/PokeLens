package com.noam.pokescan.core;

import java.util.*;

/** Builds the Hebrew info card shown in the overlay and in the app. */
public final class InfoFormatter {

    public static String basic(PokeEntry e) {
        StringBuilder b = new StringBuilder();
        b.append("#").append(e.id).append("  ").append(e.name).append('\n');
        b.append("סוג: ").append(TypeChart.he(e.type1));
        if (!e.type2.isEmpty()) b.append(" / ").append(TypeChart.he(e.type2));
        b.append('\n');
        b.append("סטטים ב-GO (משוער): התקפה ").append(e.atk).append(" · הגנה ").append(e.def)
                .append(" · סיבולת ").append(e.sta).append('\n');
        b.append("CP מקסימלי 100%: רמה 40 = ").append(IvCalc.cp(e, 15, 15, 15, 40))
                .append(" · רמה 50 = ").append(IvCalc.cp(e, 15, 15, 15, 50)).append('\n');
        b.append("CP 100% במשימה/ראיד (רמה 20): ").append(IvCalc.cp(e, 15, 15, 15, 20))
                .append(" · עם מזג אוויר (25): ").append(IvCalc.cp(e, 15, 15, 15, 25)).append('\n');
        double[] m = TypeChart.defense(e.type1, e.type2);
        b.append("חלש מול: ").append(list(m, true)).append('\n');
        b.append("עמיד מול: ").append(list(m, false)).append('\n');
        return b.toString();
    }

    static String list(double[] m, boolean weak) {
        List<Integer> idx = new ArrayList<>();
        for (int i = 0; i < m.length; i++) if (weak ? m[i] > 1.01 : m[i] < 0.99) idx.add(i);
        idx.sort((x, y) -> weak ? Double.compare(m[y], m[x]) : Double.compare(m[x], m[y]));
        if (idx.isEmpty()) return "—";
        StringBuilder b = new StringBuilder();
        for (int i : idx) {
            if (b.length() > 0) b.append(", ");
            b.append(TypeChart.HE[i]).append(" ×").append(fmt(m[i]));
        }
        return b.toString();
    }

    static String fmt(double v) {
        String s = String.format(Locale.US, "%.2f", v);
        return s.replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    static String lvl(double l) { return l == Math.floor(l) ? String.valueOf((int) l) : String.valueOf(l); }

    public static String full(Analysis a) {
        ScreenParser.Result r = a.r;
        if (r.pokemon == null) {
            StringBuilder b = new StringBuilder("לא זוהה פוקימון במסך.\n");
            if (r.cp > 0) b.append("זוהה CP ").append(r.cp).append(" (אם יש כינוי, חפש את השם באפליקציה)\n");
            b.append("טיפ: פתח מסך מפגש או מסך פרטי פוקימון ולחץ שוב על הבועה.");
            return b.toString();
        }
        StringBuilder b = new StringBuilder();
        if (a.verdict != Analysis.Verdict.NONE && r.cp > 0) {
            b.append(a.verdictText()).append('\n');
            for (String x : a.reasons) b.append("• ").append(x).append('\n');
            b.append("────────────\n");
        }
        b.append(basic(r.pokemon));
        b.append("────────────\n");
        b.append(r.ownScreen ? "מסך: פוקימון שלך\n" : "מסך: מפגש בטבע\n");
        if (r.cp > 0) b.append("CP במסך: ").append(r.cp);
        if (r.hp > 0) b.append(" · HP ").append(r.hp).append("/").append(r.hpMax);
        if (r.dust > 0) b.append(" · אבקה ").append(r.dust);
        b.append('\n');
        if (r.cp > 0) b.append(ivText(a.combos, r.ownScreen));
        if (a.gl[0] > 0 || a.ul[0] > 0) {
            b.append("PvP: ");
            if (a.gl[0] > 0) b.append("ליגה גדולה ").append(range(a.gl));
            if (a.ul[0] > 0) b.append(a.gl[0] > 0 ? " · " : "").append("אולטרה ").append(range(a.ul));
            b.append(" (מתוך 4096)\n");
        }
        if (a.combos.size() == 1) {
            IvCalc.Combo c = a.combos.get(0);
            for (int cap : new int[]{Pvp.GREAT, Pvp.ULTRA}) {
                Pvp.Info in = Pvp.info(r.pokemon, cap, c.a, c.d, c.s);
                if (in != null) b.append(cap == Pvp.GREAT ? "  גדולה" : "  אולטרה").append(": רמה ").append(lvl(in.level))
                        .append(" · CP ").append(in.cp).append(" · ").append(String.format(Locale.US, "%.1f", in.pctOfBest)).append("% מהמקסימום\n");
            }
        }
        String nick = a.nickname();
        if (!nick.isEmpty()) b.append("כינוי מוצע: ").append(nick).append('\n');
        return b.toString();
    }

    static String range(int[] r) { return r[0] == r[1] ? "#" + r[0] : "#" + r[0] + "–" + r[1]; }

    public static String ivText(List<IvCalc.Combo> c, boolean own) {
        if (c.isEmpty()) return "לא נמצא שילוב IV שמתאים (אולי ה-OCR טעה, או פוקימון מיוחד/צורה אחרת).\n";
        int min = 100, max = 0; double lmin = 99, lmax = 0;
        Set<String> mods = new TreeSet<>();
        for (IvCalc.Combo x : c) {
            min = Math.min(min, x.pct()); max = Math.max(max, x.pct());
            lmin = Math.min(lmin, x.level); lmax = Math.max(lmax, x.level);
            if (!x.mod.isEmpty()) mods.add(x.mod);
        }
        StringBuilder b = new StringBuilder();
        b.append("IV: ").append(min == max ? min + "%" : min + "%–" + max + "%")
                .append("  (").append(c.size()).append(" אפשרויות)\n");
        b.append("רמה: ").append(lmin == lmax ? lvl(lmin) : lvl(lmin) + "–" + lvl(lmax)).append('\n');
        if (!mods.isEmpty()) b.append("ייתכן: ").append(String.join(", ", mods)).append('\n');
        List<IvCalc.Combo> sorted = new ArrayList<>(c);
        sorted.sort((x, y) -> y.pct() - x.pct());
        int show = Math.min(own ? 6 : 4, sorted.size());
        for (int i = 0; i < show; i++) {
            IvCalc.Combo x = sorted.get(i);
            b.append("  ").append(x.a).append("/").append(x.d).append("/").append(x.s)
                    .append(" = ").append(x.pct()).append("% · רמה ").append(lvl(x.level));
            if (!x.mod.isEmpty()) b.append(" (").append(x.mod).append(")");
            b.append('\n');
        }
        if (!own && c.size() > 1) b.append("במפגש בטבע אין HP, לכן הטווח רחב. אחרי התפיסה פתח את הפוקימון לתוצאה מדויקת.\n");
        if (own && c.size() > 1) b.append("להקטנת האפשרויות: חזק פעם אחת וסרוק שוב.\n");
        return b.toString();
    }
}

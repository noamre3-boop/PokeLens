package com.noam.pokescan;

import android.content.Context;
import android.graphics.*;
import android.view.View;

/** Tiny bar chart drawn on a Canvas (no libraries). */
final class BarChart extends View {
    private String[] labels = new String[0];
    private int[] values = new int[0];
    private final int color;
    private final Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG), txt = new Paint(Paint.ANTI_ALIAS_FLAG), grid = new Paint();
    private final RectF r = new RectF();

    BarChart(Context c, int color) {
        super(c);
        this.color = color;
        txt.setColor(0xFFAFC0E0);
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setTextSize(Ui.dp(c, 11));
        grid.setColor(0x22FFFFFF);
        grid.setStrokeWidth(Ui.dp(c, 1));
    }

    void set(String[] labels, int[] values) { this.labels = labels; this.values = values; invalidate(); }

    @Override protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dp(getContext(), 150));
    }

    @Override protected void onDraw(Canvas c) {
        int n = values.length;
        if (n == 0) return;
        float w = getWidth(), h = getHeight(), labelH = Ui.dp(getContext(), 18), valH = Ui.dp(getContext(), 16);
        float chartH = h - labelH - valH;
        int max = 1;
        for (int v : values) max = Math.max(max, v);
        c.drawLine(0, valH + chartH, w, valH + chartH, grid);
        float slot = w / n, bw = slot * 0.62f;
        int labelEvery = n > 12 ? 3 : 1;
        for (int i = 0; i < n; i++) {
            float cx = slot * i + slot / 2, bh = chartH * values[i] / max;
            if (values[i] > 0) {
                bar.setShader(new LinearGradient(0, valH + chartH - bh, 0, valH + chartH, color, (color & 0x00FFFFFF) | 0x66000000, Shader.TileMode.CLAMP));
                r.set(cx - bw / 2, valH + chartH - Math.max(bh, Ui.dp(getContext(), 3)), cx + bw / 2, valH + chartH);
                c.drawRoundRect(r, Ui.dp(getContext(), 4), Ui.dp(getContext(), 4), bar);
                if (n <= 12) c.drawText(String.valueOf(values[i]), cx, valH + chartH - bh - Ui.dp(getContext(), 4), txt);
            }
            if (i % labelEvery == 0 && i < labels.length) c.drawText(labels[i], cx, h - Ui.dp(getContext(), 4), txt);
        }
    }
}

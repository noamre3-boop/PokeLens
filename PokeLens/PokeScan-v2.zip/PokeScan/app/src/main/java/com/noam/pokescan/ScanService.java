package com.noam.pokescan;

import android.annotation.SuppressLint;
import android.app.*;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.*;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.noam.pokescan.core.*;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.speech.tts.TextToSpeech;

import java.nio.ByteBuffer;
import java.util.*;

/**
 * Foreground service: mirrors the screen into an ImageReader, runs on-device OCR when asked,
 * and shows a floating info card. Read-only – it never injects touches or talks to game servers.
 */
public class ScanService extends Service {
    static final String EXTRA_CODE = "code", EXTRA_DATA = "data", ACTION_STOP = "stop", CHANNEL = "scan", ALERTS = "alerts";
    static volatile boolean running;

    MediaProjection projection;
    VirtualDisplay display;
    ImageReader reader;
    HandlerThread thread;
    Handler bg, main = new Handler(Looper.getMainLooper());
    WindowManager wm;
    TextView bubble, cardText;
    LinearLayout card;
    TextRecognizer ocr;
    volatile Bitmap latest;
    volatile long lastFrame;
    boolean busy, auto;
    float scale = 1f;
    int capW, capH, screenW, screenH;
    String lastKey = "";
    TextView cardTitle;
    Analysis current;
    // encounter tracking (only from what is seen on screen)
    Event pending; Analysis pendingA; String pendingKey = ""; long pendingAt;
    TextToSpeech tts; boolean ttsReady;
    int alertId = 100;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (projection != null) return START_NOT_STICKY;

        startInForeground();
        int code = intent.getIntExtra(EXTRA_CODE, 0);
        Intent data = Build.VERSION.SDK_INT >= 33 ? intent.getParcelableExtra(EXTRA_DATA, Intent.class)
                : intent.getParcelableExtra(EXTRA_DATA);
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = data == null ? null : mpm.getMediaProjection(code, data);
        if (projection == null) { stopSelf(); return START_NOT_STICKY; }
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { main.post(ScanService.this::stopSelf); }
        }, main);

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        ocr = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        MainActivity.db(this);
        tts = new TextToSpeech(this, st -> {
            if (st == TextToSpeech.SUCCESS) ttsReady = tts.setLanguage(new Locale("he", "IL")) >= 0;
        });
        startCapture();
        showBubble();
        running = true;
        if (Store.autoStart(this)) main.postDelayed(() -> { if (!auto) toggleAuto(); }, 800);
        return START_NOT_STICKY;
    }

    void startInForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "PokeScan", NotificationManager.IMPORTANCE_LOW));
        NotificationChannel al = new NotificationChannel(ALERTS, "התראות פוקימון", NotificationManager.IMPORTANCE_HIGH);
        al.enableVibration(false); // we vibrate ourselves, according to the settings
        nm.createNotificationChannel(al);
        Notification n = statusNotification("לחץ על הבועה כדי לסרוק · " + todayLine());
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(1, n);
    }

    String todayLine() {
        Stats st = Stats.of(Store.log(this).all(), System.currentTimeMillis(), TimeZone.getDefault());
        return "היום: " + st.todayCaught + " נתפסו · " + st.todayShiny + " ✨";
    }

    void updateStatus() {
        getSystemService(NotificationManager.class).notify(1, statusNotification(todayLine()));
    }

    Notification statusNotification(String text) {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, ScanService.class).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("PokeScan פועל")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_search)
                .setOngoing(true)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(null, "עצור", stop).build())
                .build();
        return n;
    }

    @SuppressWarnings("deprecation")
    void startCapture() {
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        screenW = dm.widthPixels; screenH = dm.heightPixels;
        scale = Math.min(1f, 1080f / Math.min(screenW, screenH)); // keep OCR fast on very high-res screens
        capW = Math.round(screenW * scale); capH = Math.round(screenH * scale);

        thread = new HandlerThread("capture");
        thread.start();
        bg = new Handler(thread.getLooper());
        reader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2);
        reader.setOnImageAvailableListener(r -> {
            Image img = null;
            try {
                img = r.acquireLatestImage();
                if (img == null) return;
                long now = SystemClock.uptimeMillis();
                if (now - lastFrame < 350) return; // ~3 fps is plenty, saves battery
                lastFrame = now;
                latest = toBitmap(img);
            } catch (Exception ignored) {
            } finally { if (img != null) img.close(); }
        }, bg);
        display = projection.createVirtualDisplay("pokescan", capW, capH, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, bg);
    }

    Bitmap toBitmap(Image img) {
        Image.Plane p = img.getPlanes()[0];
        ByteBuffer buf = p.getBuffer();
        int ps = p.getPixelStride(), rs = p.getRowStride();
        int rowPad = rs - ps * capW;
        Bitmap bmp = Bitmap.createBitmap(capW + rowPad / ps, capH, Bitmap.Config.ARGB_8888);
        bmp.copyPixelsFromBuffer(buf);
        if (rowPad > 0) {
            Bitmap cropped = Bitmap.createBitmap(bmp, 0, 0, capW, capH);
            bmp.recycle();
            bmp = cropped;
        }
        return bmp;
    }

    // ───────────── overlay ─────────────
    WindowManager.LayoutParams overlayParams(int w, int h) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        return lp;
    }

    @SuppressLint("ClickableViewAccessibility")
    void showBubble() {
        int size = Ui.dp(this, 58);
        bubble = new TextView(this);
        bubble.setText("🔍");
        bubble.setTextSize(24);
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackground(Ui.round(Ui.ACCENT, 29, this));
        bubble.setElevation(Ui.dp(this, 6));
        WindowManager.LayoutParams lp = overlayParams(size, size);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = Ui.dp(this, 8);
        lp.y = screenH / 3;
        int slop = Ui.dp(this, 10);
        Runnable longPress = this::toggleAuto;
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY; boolean moved, longFired;
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX(); downY = e.getRawY(); startX = lp.x; startY = lp.y;
                        moved = false; longFired = false;
                        main.postDelayed(() -> { if (!moved) { longFired = true; longPress.run(); } }, 650);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                        if (!moved && Math.hypot(dx, dy) > slop) { moved = true; main.removeCallbacksAndMessages(null); }
                        if (moved) { lp.x = startX + (int) dx; lp.y = startY + (int) dy; wm.updateViewLayout(bubble, lp); }
                        return true;
                    case MotionEvent.ACTION_UP:
                        main.removeCallbacksAndMessages(null);
                        if (auto) main.postDelayed(autoTick, Store.intervalMs(ScanService.this));
                        if (!moved && !longFired) scan(false);
                        return true;
                }
                return false;
            }
        });
        wm.addView(bubble, lp);
    }

    void ensureCard() {
        if (card != null) return;
        int pad = Ui.dp(this, 12);
        card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(pad, pad / 2, pad, pad);
        card.setBackground(Ui.round(Ui.CARD, 18, this));
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        cardTitle = Ui.text(this, "PokeScan", 16, Ui.ACCENT);
        cardTitle.setTypeface(Typeface.DEFAULT_BOLD);
        head.addView(cardTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView close = Ui.text(this, "✕", 22, Color.WHITE);
        close.setPadding(pad, 0, 0, 0);
        close.setOnClickListener(v -> hideCard());
        head.addView(close);
        card.addView(head);

        ScrollView sv = new ScrollView(this);
        cardText = Ui.text(this, "", 13.5f, Ui.TEXT);
        cardText.setLineSpacing(0, 1.12f);
        sv.addView(cardText);
        card.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) (screenH * 0.32f)));

        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, pad / 2, 0, 0);
        String[] labels = {"✓ נתפס", "✨ שייני", "✗ ברח", "📋 כינוי"};
        int[] colors = {0xFF2E8B57, 0xFF7A4FD8, 0xFF8A2D3B, Ui.BLUE};
        for (int i = 0; i < 4; i++) {
            final int k = i;
            Button b = Ui.button(this, labels[i], colors[i]);
            b.setTextSize(13);
            b.setPadding(0, 0, 0, 0);
            b.setOnClickListener(v -> cardAction(k));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1);
            lp.setMargins(Ui.dp(this, 3), 0, Ui.dp(this, 3), 0);
            row.addView(b, lp);
        }
        card.addView(row);

        WindowManager.LayoutParams lp = overlayParams((int) (screenW * 0.94f), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        lp.y = Ui.dp(this, 20);
        card.setVisibility(View.GONE);
        wm.addView(card, lp);
    }

    void showCard(String s) { showCard("PokeScan", Ui.ACCENT, s); }

    void showCard(String title, int color, String s) {
        ensureCard();
        cardTitle.setText(title);
        cardTitle.setTextColor(color);
        cardText.setText(s);
        card.setVisibility(View.VISIBLE);
    }

    void showAnalysis(Analysis a) {
        current = a;
        int color = a.verdict == Analysis.Verdict.MUST ? 0xFFFF6BD6 : a.verdict == Analysis.Verdict.CATCH ? 0xFF3DDC84 : Ui.ACCENT;
        String title = a.r.pokemon == null ? "PokeScan" : a.r.pokemon.name + (a.r.cp > 0 ? " · CP " + a.r.cp : "");
        showCard(title, color, InfoFormatter.full(a));
    }

    // ───────────── logging (all driven by what is visible on screen or by your taps) ─────────────
    void logCaught(boolean shiny) {
        EventLog log = Store.log(this);
        if (pending != null) {
            log.add(new Event(System.currentTimeMillis(), 'C', pending.id, pending.name, pending.cp,
                    pendingA == null ? -1 : pendingA.ivMin, pendingA == null ? -1 : pendingA.ivMax, shiny));
            toast((shiny ? "✨ שייני נרשם: " : "✓ נרשם: ") + pending.name);
            pending = null; pendingA = null;
        } else if (shiny) {
            if (log.last('C') == null) { toast("אין תפיסה ביומן לסמן"); return; }
            log.markLastCaughtShiny(true);
            toast("✨ התפיסה האחרונה סומנה כשייני");
        } else if (current != null && current.r.pokemon != null) {
            PokeEntry e = current.r.pokemon;
            log.add(new Event(System.currentTimeMillis(), 'C', e.id, e.name, current.r.cp, current.ivMin, current.ivMax, false));
            toast("✓ נרשם: " + e.name);
        } else { toast("אין פוקימון לרשום"); return; }
        updateStatus();
    }

    void cardAction(int k) {
        switch (k) {
            case 0: logCaught(false); break;
            case 1: logCaught(true); break;
            case 2:
                if (pending == null) { toast("אין מפגש פתוח"); break; }
                Store.log(this).add(new Event(System.currentTimeMillis(), 'F', pending.id, pending.name, pending.cp,
                        pendingA == null ? -1 : pendingA.ivMin, pendingA == null ? -1 : pendingA.ivMax, false));
                toast("✗ נרשם שברח: " + pending.name);
                pending = null; pendingA = null;
                break;
            case 3:
                String nick = current == null ? "" : current.nickname();
                if (nick.isEmpty()) { toast("אין כינוי – סרוק פוקימון קודם"); break; }
                ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("nickname", nick));
                toast("📋 הועתק: " + nick + " – הדבק בעצמך בשם הפוקימון");
                break;
        }
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    void alert(Analysis a) {
        boolean worth = a.verdict == Analysis.Verdict.MUST || a.verdict == Analysis.Verdict.CATCH;
        if (worth && Store.vibrate(this)) {
            Vibrator v = getSystemService(Vibrator.class);
            if (v != null && v.hasVibrator()) {
                long[] pattern = a.verdict == Analysis.Verdict.MUST ? new long[]{0, 120, 90, 120, 90, 300} : new long[]{0, 90};
                v.vibrate(VibrationEffect.createWaveform(pattern, -1));
            }
        }
        if (Store.speak(this) && ttsReady && (worth || Store.notifyAll(this)))
            tts.speak(a.speech(), TextToSpeech.QUEUE_FLUSH, null, "pk");
        if (!worth && !Store.notifyAll(this)) return;
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return;
        String body = String.join(" · ", a.reasons);
        Notification n = new Notification.Builder(this, ALERTS)
                .setSmallIcon(android.R.drawable.star_on)
                .setContentTitle(a.r.pokemon.name + " CP " + a.r.cp + " – " + a.verdictText())
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setTimeoutAfter(60_000)
                .build();
        getSystemService(NotificationManager.class).notify(alertId++, n);
    }

    /** Called with every OCR result. Only reads & records – never acts inside the game. */
    void handle(Analysis a, boolean silent) {
        ScreenParser.Result r = a.r;
        long now = System.currentTimeMillis();
        EventLog log = Store.log(this);
        if (r.fled && pending != null) {
            log.add(new Event(now, 'F', pending.id, pending.name, pending.cp,
                    pendingA == null ? -1 : pendingA.ivMin, pendingA == null ? -1 : pendingA.ivMax, false));
            showCard("ברח 😕", 0xFFFF7A7A, pending.name + " ברח. נרשם ביומן.");
            pending = null; pendingA = null;
            updateStatus();
            return;
        }
        if (r.isList()) {
            if (!silent) showCard("מסך רשימה – פתח פוקימון אחד כדי לסרוק אותו.");
            return;
        }
        if (r.isWild()) {
            String key = r.pokemon.id + ":" + r.cp;
            boolean same = pending != null && key.equals(pendingKey) && now - pendingAt < 180_000;
            if (!same) {
                pending = new Event(now, 'E', r.pokemon.id, r.pokemon.name, r.cp, a.ivMin, a.ivMax, false);
                pendingA = a; pendingKey = key; pendingAt = now;
                log.add(pending);
                alert(a);
            } else if (silent) return;
            lastKey = key;
            showAnalysis(a);
            return;
        }
        if (r.isOwn()) {
            if (pending != null && pending.id == r.pokemon.id && pending.cp == r.cp && now - pendingAt < 600_000) {
                // the details screen of the Pokemon you just caught -> exact IVs
                log.add(new Event(now, 'C', r.pokemon.id, r.pokemon.name, r.cp, a.ivMin, a.ivMax, false));
                pending = null; pendingA = null;
                toast("✓ נתפס ונרשם: " + r.pokemon.name + " (שייני? לחץ ✨)");
                if (Store.speak(this) && ttsReady) tts.speak("נתפס. " + a.speech(), TextToSpeech.QUEUE_FLUSH, null, "pk");
                updateStatus();
            }
            String key = "own:" + r.pokemon.id + ":" + r.cp + ":" + r.hp + ":" + r.dust;
            if (silent && key.equals(lastKey)) return;
            lastKey = key;
            showAnalysis(a);
            return;
        }
        if (!silent) showAnalysis(a);
    }

    void hideCard() { if (card != null) card.setVisibility(View.GONE); lastKey = ""; }

    void toggleAuto() {
        auto = !auto;
        bubble.setBackground(Ui.round(auto ? 0xFF3DDC84 : Ui.ACCENT, 29, this));
        Toast.makeText(this, auto ? "סריקה אוטומטית: פועל" : "סריקה אוטומטית: כבוי", Toast.LENGTH_SHORT).show();
        main.removeCallbacks(autoTick);
        if (auto) main.postDelayed(autoTick, 500);
    }

    final Runnable autoTick = new Runnable() {
        @Override public void run() {
            if (!auto || !running) return;
            scan(true);
            main.postDelayed(this, Store.intervalMs(ScanService.this));
        }
    };

    // ───────────── OCR ─────────────
    List<Rect> overlayRects() {
        List<Rect> out = new ArrayList<>();
        for (View v : new View[]{bubble, card}) {
            if (v == null || v.getVisibility() != View.VISIBLE || v.getWidth() == 0) continue;
            int[] loc = new int[2];
            v.getLocationOnScreen(loc);
            out.add(new Rect((int) (loc[0] * scale), (int) (loc[1] * scale),
                    (int) ((loc[0] + v.getWidth()) * scale), (int) ((loc[1] + v.getHeight()) * scale)));
        }
        return out;
    }

    void scan(boolean silent) {
        if (busy) return;
        Bitmap bmp = latest;
        if (bmp == null) { if (!silent) Toast.makeText(this, "ממתין לתמונת מסך…", Toast.LENGTH_SHORT).show(); return; }
        busy = true;
        List<Rect> skip = overlayRects(); // ignore our own bubble/card so we never read our own text
        int bucket = Math.max(1, capH / 70);
        ocr.process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener(text -> {
                    List<Text.Line> found = new ArrayList<>();
                    for (Text.TextBlock b : text.getTextBlocks())
                        for (Text.Line l : b.getLines()) {
                            Rect r = l.getBoundingBox();
                            boolean mine = false;
                            if (r != null) for (Rect s : skip) if (Rect.intersects(s, r)) { mine = true; break; }
                            if (!mine) found.add(l);
                        }
                    found.sort((a, b) -> {
                        Rect ra = a.getBoundingBox(), rb = b.getBoundingBox();
                        if (ra == null || rb == null) return 0;
                        int c = Integer.compare(ra.top / bucket, rb.top / bucket);
                        return c != 0 ? c : Integer.compare(ra.left, rb.left);
                    });
                    List<String> lines = new ArrayList<>();
                    for (Text.Line l : found) lines.add(l.getText());
                    ScreenParser.Result res = ScreenParser.parse(lines, MainActivity.db(this));
                    if (silent && res.pokemon == null && !res.fled) return;
                    handle(Analysis.of(res, Store.settings(this), Store.log(this)), silent);
                })
                .addOnFailureListener(e -> { if (!silent) showCard("שגיאת זיהוי: " + e.getMessage()); })
                .addOnCompleteListener(t -> busy = false);
    }

    @Override public void onDestroy() {
        running = false;
        auto = false;
        main.removeCallbacksAndMessages(null);
        try { if (bubble != null) wm.removeView(bubble); } catch (Exception ignored) {}
        try { if (card != null) wm.removeView(card); } catch (Exception ignored) {}
        if (display != null) display.release();
        if (reader != null) reader.close();
        MediaProjection p = projection;
        projection = null;
        if (p != null) try { p.stop(); } catch (Exception ignored) {}
        if (thread != null) thread.quitSafely();
        if (ocr != null) ocr.close();
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }
}

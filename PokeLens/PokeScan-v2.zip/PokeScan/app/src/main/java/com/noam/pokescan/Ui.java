package com.noam.pokescan;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.Button;
import android.widget.TextView;

final class Ui {
    static final int BG = 0xFF101826, CARD = 0xEE162236, ACCENT = 0xFFFFCB05, BLUE = 0xFF3B6FD8, TEXT = 0xFFEAF0FF;

    static int dp(Context c, float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics());
    }

    static GradientDrawable round(int color, float radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static TextView text(Context c, String s, float sp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTextDirection(TextView.TEXT_DIRECTION_RTL);
        return t;
    }

    static Button button(Context c, String s, int color) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(color == ACCENT ? Color.BLACK : Color.WHITE);
        b.setTextSize(16);
        b.setBackground(round(color, 14, c));
        b.setGravity(Gravity.CENTER);
        return b;
    }
}

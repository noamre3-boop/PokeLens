package com.noam.pokescan.core;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** All Pokemon, loaded from assets/pokemon.tsv (generated at build time). */
public final class PokeDb {
    public final List<PokeEntry> all = new ArrayList<>();
    private final Map<String, PokeEntry> byKey = new HashMap<>();

    public PokeDb(InputStream in) throws IOException {
        BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        String line;
        while ((line = r.readLine()) != null) {
            String[] p = line.split("\t", -1);
            if (p.length < 7) continue;
            PokeEntry e = new PokeEntry(Integer.parseInt(p[0]), p[1], p[2], p[3],
                    Integer.parseInt(p[4]), Integer.parseInt(p[5]), Integer.parseInt(p[6]));
            all.add(e);
            byKey.put(e.key, e);
        }
    }

    public static String norm(String s) {
        StringBuilder b = new StringBuilder();
        for (char c : s.toLowerCase(Locale.ROOT).toCharArray())
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) b.append(c);
        return b.toString();
    }

    public PokeEntry byId(int id) {
        for (PokeEntry e : all) if (e.id == id) return e;
        return null;
    }

    /** Exact match, then fuzzy (OCR mistakes). Returns null if nothing is close enough. */
    public PokeEntry find(String text) {
        String k = norm(text);
        if (k.length() < 3) return null;
        PokeEntry e = byKey.get(k);
        if (e != null) return e;
        if (k.length() <= 4) return null; // short names must be exact, too risky
        int maxDist = Math.max(1, k.length() / 5);
        PokeEntry best = null; int bestD = Integer.MAX_VALUE;
        for (PokeEntry c : all) {
            if (Math.abs(c.key.length() - k.length()) > maxDist) continue;
            int d = lev(k, c.key, maxDist);
            if (d < bestD) { bestD = d; best = c; }
        }
        return bestD <= maxDist ? best : null;
    }

    /** Suggestions for manual search (prefix / contains). */
    public List<PokeEntry> search(String text, int limit) {
        String k = norm(text);
        List<PokeEntry> out = new ArrayList<>();
        if (k.isEmpty()) return out;
        try { PokeEntry e = byId(Integer.parseInt(k)); if (e != null) out.add(e); } catch (NumberFormatException ignored) {}
        for (PokeEntry e : all) if (e.key.startsWith(k) && !out.contains(e)) out.add(e);
        for (PokeEntry e : all) if (e.key.contains(k) && !out.contains(e)) out.add(e);
        if (out.isEmpty()) { PokeEntry f = find(text); if (f != null) out.add(f); }
        return out.size() > limit ? out.subList(0, limit) : out;
    }

    static int lev(String a, String b, int cap) {
        int[] prev = new int[b.length() + 1], cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i; int rowMin = cur[0];
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
                rowMin = Math.min(rowMin, cur[j]);
            }
            if (rowMin > cap) return cap + 1;
            int[] t = prev; prev = cur; cur = t;
        }
        return prev[b.length()];
    }
}

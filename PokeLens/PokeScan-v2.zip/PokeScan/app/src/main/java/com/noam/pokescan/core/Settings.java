package com.noam.pokescan.core;

import java.util.*;

/** User rules for the decision engine (plain Java so it can be unit-tested). */
public final class Settings {
    public int minIv = 90;          // IV% considered "high"
    public int pvpTop = 20;         // PvP rank considered "good"
    public boolean newSpecies = true;
    public final Set<String> watch = new HashSet<>();

    public void setWatch(String csv) {
        watch.clear();
        if (csv == null) return;
        for (String p : csv.split("[,\\n]")) { String k = PokeDb.norm(p); if (!k.isEmpty()) watch.add(k); }
    }
}

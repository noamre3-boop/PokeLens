package com.noam.pokescan.core;

import java.util.*;

/** Parse result + IV candidates + PvP ranks + catch/skip decision. */
public final class Analysis {
    public enum Verdict { MUST, CATCH, SKIP, NONE }

    public final ScreenParser.Result r;
    public List<IvCalc.Combo> combos = Collections.emptyList();
    public int ivMin = -1, ivMax = -1;
    public int[] gl = {-1, -1}, ul = {-1, -1};
    public Verdict verdict = Verdict.NONE;
    public final List<String> reasons = new ArrayList<>();
    public boolean newSpecies;

    private Analysis(ScreenParser.Result r) { this.r = r; }

    public static Analysis of(ScreenParser.Result r, Settings s, EventLog log) {
        Analysis a = new Analysis(r);
        if (r.pokemon == null) return a;
        PokeEntry e = r.pokemon;
        if (r.cp > 0) {
            a.combos = IvCalc.solve(e, r.cp, r.ownScreen ? r.hpMax : -1, r.dust, !r.ownScreen);
            for (IvCalc.Combo c : a.combos) {
                a.ivMin = a.ivMin < 0 ? c.pct() : Math.min(a.ivMin, c.pct());
                a.ivMax = Math.max(a.ivMax, c.pct());
            }
            if (!a.combos.isEmpty() && a.combos.size() <= 600) {
                a.gl = Pvp.rankRange(e, Pvp.GREAT, a.combos);
                a.ul = Pvp.rankRange(e, Pvp.ULTRA, a.combos);
            }
        }
        a.newSpecies = log != null && !log.hasCaught(e.id);
        a.decide(s);
        return a;
    }

    void decide(Settings s) {
        PokeEntry e = r.pokemon;
        boolean must = false, catchIt = false;
        if (s.watch.contains(e.key)) { must = true; reasons.add("ברשימת המבוקשים שלך"); }
        if (ivMin >= 100) { must = true; reasons.add("100% מושלם!"); }
        else if (ivMin >= s.minIv) { catchIt = true; reasons.add("IV גבוה (" + ivMin + "%+)"); }
        else if (ivMax >= 100 && combos.size() <= 40) { catchIt = true; reasons.add("יכול להיות 100%"); }
        else if (ivMax >= s.minIv && ivMin >= 0) reasons.add("אולי IV גבוה (עד " + ivMax + "%)");
        boolean exactish = combos.size() <= 16; // wild screens give too many options to trust PvP rank
        if (gl[0] > 0 && gl[0] <= s.pvpTop) {
            if (exactish) { catchIt = true; reasons.add("ליגה גדולה: מקום " + rng(gl)); }
            else reasons.add("אולי טוב לליגה גדולה (מקום " + gl[0] + " במקרה הטוב)");
        }
        if (ul[0] > 0 && ul[0] <= s.pvpTop) {
            if (exactish) { catchIt = true; reasons.add("ליגה אולטרה: מקום " + rng(ul)); }
            else reasons.add("אולי טוב לליגה אולטרה (מקום " + ul[0] + " במקרה הטוב)");
        }
        if (s.newSpecies && newSpecies) { catchIt = true; reasons.add("חדש בפוקידקס שלך (לפי היומן)"); }
        verdict = must ? Verdict.MUST : catchIt ? Verdict.CATCH : Verdict.SKIP;
        if (verdict == Verdict.SKIP) reasons.add("פוקימון רגיל – תלוי אם צריך סוכריות/אבקה");
    }

    static String rng(int[] r) { return r[0] == r[1] ? String.valueOf(r[0]) : r[0] + "–" + r[1]; }

    public String verdictText() {
        switch (verdict) {
            case MUST: return "💎 חובה לתפוס";
            case CATCH: return "✅ כדאי לתפוס";
            case SKIP: return "➖ אפשר לוותר";
            default: return "";
        }
    }

    /** Short nickname (max 12 chars) to paste in the game, e.g. "91★G3U12". */
    public String nickname() {
        if (ivMax < 0) return "";
        StringBuilder b = new StringBuilder();
        b.append(ivMin == ivMax ? String.valueOf(ivMax) : ivMin + "-" + ivMax);
        if (ivMin >= 90) b.append('★');
        if (gl[0] > 0 && gl[0] <= 100) b.append('G').append(gl[0]);
        if (ul[0] > 0 && ul[0] <= 100) b.append('U').append(ul[0]);
        return b.length() > 12 ? b.substring(0, 12) : b.toString();
    }

    public String speech() {
        if (r.pokemon == null) return "";
        String v = verdict == Verdict.MUST ? "חובה לתפוס" : verdict == Verdict.CATCH ? "כדאי לתפוס" : "אפשר לוותר";
        String iv = ivMin < 0 ? "" : ivMin == ivMax ? ", " + ivMin + " אחוז" : ", " + ivMin + " עד " + ivMax + " אחוז";
        return r.pokemon.name + iv + ". " + v;
    }
}

package com.noam.pokescan;

import android.content.Context;
import android.content.SharedPreferences;

import com.noam.pokescan.core.*;

import java.io.File;

/** Shared singletons: event log + user settings (SharedPreferences). */
final class Store {
    private static EventLog log;

    static synchronized EventLog log(Context c) {
        if (log == null) log = new EventLog(new File(c.getApplicationContext().getFilesDir(), "events.tsv"));
        return log;
    }

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("pokescan", Context.MODE_PRIVATE); }

    static Settings settings(Context c) {
        SharedPreferences p = prefs(c);
        Settings s = new Settings();
        s.minIv = p.getInt("minIv", 90);
        s.pvpTop = p.getInt("pvpTop", 20);
        s.newSpecies = p.getBoolean("newSpecies", true);
        s.setWatch(p.getString("watch", ""));
        return s;
    }

    static boolean speak(Context c) { return prefs(c).getBoolean("speak", false); }
    static boolean vibrate(Context c) { return prefs(c).getBoolean("vibrate", true); }
    static boolean notifyAll(Context c) { return prefs(c).getBoolean("notifyAll", false); }
    static boolean autoStart(Context c) { return prefs(c).getBoolean("autoStart", true); }
    static int intervalMs(Context c) { return Math.max(1000, prefs(c).getInt("intervalSec", 2) * 1000); }
}

package com.noam.pokescan.core;

import java.util.*;

/** Everything the dashboard shows, computed from the event log. */
public final class Stats {
    public static final int DEX_SIZE = 1025;
    public int seen, caught, fled, shiny, hundos, high, uniqueCaught, todayCaught, todaySeen, todayShiny, streakDays;
    public long avgCp;
    public int bestCp = -1; public String bestCpName = "";
    public final int[] last7 = new int[7];     // caught per day, [6] = today
    public final String[] last7Labels = new String[7];
    public final int[] hours = new int[24];    // caught per hour of day
    public final int[] ivBuckets = new int[5]; // <50, 50-79, 80-89, 90-99, 100
    public final List<Map.Entry<String, Integer>> topSpecies = new ArrayList<>();
    public final List<Event> shinies = new ArrayList<>(), best = new ArrayList<>();

    public double catchRate() { int t = caught + fled; return t == 0 ? 0 : caught * 100.0 / t; }
    public String shinyRate() { return shiny == 0 ? "—" : "1:" + Math.max(1, Math.round((double) Math.max(seen, caught) / shiny)); }
    public double dexPct() { return uniqueCaught * 100.0 / DEX_SIZE; }

    static long dayKey(long t, TimeZone tz) { return (t + tz.getOffset(t)) / 86_400_000L; }

    public static Stats of(List<Event> events, long now, TimeZone tz) {
        Stats s = new Stats();
        long today = dayKey(now, tz);
        Map<String, Integer> species = new HashMap<>();
        Set<Integer> unique = new HashSet<>(), days = new HashSet<>();
        long cpSum = 0;
        String[] dn = {"א׳", "ב׳", "ג׳", "ד׳", "ה׳", "ו׳", "ש׳"};
        Calendar cal = Calendar.getInstance(tz);
        for (int i = 0; i < 7; i++) {
            cal.setTimeInMillis(now - (6 - i) * 86_400_000L);
            s.last7Labels[i] = i == 6 ? "היום" : dn[cal.get(Calendar.DAY_OF_WEEK) - 1];
        }
        for (Event e : events) {
            long dk = dayKey(e.time, tz);
            if (e.type == 'E') { s.seen++; if (dk == today) s.todaySeen++; continue; }
            if (e.type == 'F') { s.fled++; continue; }
            if (e.type != 'C') continue;
            s.caught++;
            days.add((int) dk);
            unique.add(e.id);
            species.merge(e.name, 1, Integer::sum);
            cpSum += e.cp;
            if (e.cp > s.bestCp) { s.bestCp = e.cp; s.bestCpName = e.name; }
            if (e.shiny) { s.shiny++; s.shinies.add(e); if (dk == today) s.todayShiny++; }
            if (dk == today) s.todayCaught++;
            long ago = today - dk;
            if (ago >= 0 && ago < 7) s.last7[6 - (int) ago]++;
            cal.setTimeInMillis(e.time);
            s.hours[cal.get(Calendar.HOUR_OF_DAY)]++;
            if (e.ivMin >= 0) {
                int mid = (e.ivMin + e.ivMax) / 2;
                if (e.ivMin >= 100) { s.hundos++; s.ivBuckets[4]++; }
                else if (mid >= 90) s.ivBuckets[3]++;
                else if (mid >= 80) s.ivBuckets[2]++;
                else if (mid >= 50) s.ivBuckets[1]++;
                else s.ivBuckets[0]++;
                if (e.ivMin >= 90) s.high++;
                s.best.add(e);
            }
        }
        s.uniqueCaught = unique.size();
        s.avgCp = s.caught == 0 ? 0 : cpSum / s.caught;
        for (long d = today; days.contains((int) d); d--) s.streakDays++;
        if (s.streakDays == 0) for (long d = today - 1; days.contains((int) d); d--) s.streakDays++;
        s.topSpecies.addAll(species.entrySet());
        s.topSpecies.sort((a, b) -> b.getValue() - a.getValue());
        if (s.topSpecies.size() > 5) s.topSpecies.subList(5, s.topSpecies.size()).clear();
        s.best.sort((a, b) -> b.ivMin != a.ivMin ? b.ivMin - a.ivMin : b.ivMax - a.ivMax);
        if (s.best.size() > 5) s.best.subList(5, s.best.size()).clear();
        Collections.reverse(s.shinies);
        return s;
    }
}

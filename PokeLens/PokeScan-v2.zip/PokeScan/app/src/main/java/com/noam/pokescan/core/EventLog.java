package com.noam.pokescan.core;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Append-only-ish local log (a TSV file on the phone). Thread-safe. */
public final class EventLog {
    private final File file;
    private final List<Event> events = new ArrayList<>();
    private long version;

    public EventLog(File file) {
        this.file = file;
        if (file.exists()) {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
                String l;
                while ((l = r.readLine()) != null) { Event e = Event.parse(l); if (e != null) events.add(e); }
            } catch (IOException ignored) {}
        }
    }

    public synchronized List<Event> all() { return new ArrayList<>(events); }
    public synchronized long version() { return version; }

    public synchronized void add(Event e) {
        events.add(e);
        version++;
        try (Writer w = new OutputStreamWriter(new FileOutputStream(file, true), StandardCharsets.UTF_8)) {
            w.write(e.toLine() + "\n");
        } catch (IOException ignored) {}
    }

    public synchronized Event last(char type) {
        for (int i = events.size() - 1; i >= 0; i--) if (events.get(i).type == type) return events.get(i);
        return null;
    }

    public synchronized boolean hasCaught(int id) {
        for (Event e : events) if (e.type == 'C' && e.id == id) return true;
        return false;
    }

    public synchronized void markLastCaughtShiny(boolean shiny) {
        Event e = last('C');
        if (e != null) { e.shiny = shiny; rewrite(); }
    }

    public synchronized Event removeLast() {
        if (events.isEmpty()) return null;
        Event e = events.remove(events.size() - 1);
        rewrite();
        return e;
    }

    public synchronized void clear() { events.clear(); rewrite(); }

    private void rewrite() {
        version++;
        try (Writer w = new OutputStreamWriter(new FileOutputStream(file, false), StandardCharsets.UTF_8)) {
            for (Event e : events) w.write(e.toLine() + "\n");
        } catch (IOException ignored) {}
    }

    public synchronized String toCsv() {
        StringBuilder b = new StringBuilder("\uFEFFdate,type,dex,name,cp,iv_min,iv_max,shiny\n");
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
        for (Event e : events)
            b.append(f.format(new Date(e.time))).append(',')
                    .append(e.type == 'C' ? "caught" : e.type == 'F' ? "fled" : "seen").append(',')
                    .append(e.id).append(',').append(e.name.replace(",", " ")).append(',').append(e.cp).append(',')
                    .append(e.ivMin).append(',').append(e.ivMax).append(',').append(e.shiny ? 1 : 0).append('\n');
        return b.toString();
    }
}

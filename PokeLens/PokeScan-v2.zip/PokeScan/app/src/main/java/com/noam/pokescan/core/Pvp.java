package com.noam.pokescan.core;

import java.util.*;

/** PvP IV ranking (stat product under a league CP cap), like the community rank checkers. */
public final class Pvp {
    public static final int GREAT = 1500, ULTRA = 2500;
    private static final Map<String, int[]> RANKS = new HashMap<>();
    private static final Map<String, double[]> PRODUCTS = new HashMap<>();

    public static final class Info {
        public int rank; public double level; public int cp; public double pctOfBest;
    }

    static int idx(int a, int d, int s) { return a * 256 + d * 16 + s; }

    /** Highest level index (0..98) with CP <= cap, or -1. */
    static int maxLevelIndex(PokeEntry e, int a, int d, int s, int cap) {
        int lo = 0, hi = IvCalc.CPM.length - 1, best = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (IvCalc.cp(e, a, d, s, 1 + mid * 0.5) <= cap) { best = mid; lo = mid + 1; } else hi = mid - 1;
        }
        return best;
    }

    static double product(PokeEntry e, int a, int d, int s, int li) {
        double m = IvCalc.CPM[li];
        return (e.atk + a) * m * (e.def + d) * m * Math.floor((e.sta + s) * m);
    }

    private static synchronized void build(PokeEntry e, int cap) {
        String k = e.id + ":" + cap;
        if (RANKS.containsKey(k)) return;
        double[] sp = new double[4096];
        Integer[] order = new Integer[4096];
        boolean any = false;
        for (int a = 0; a < 16; a++) for (int d = 0; d < 16; d++) for (int s = 0; s < 16; s++) {
            int i = idx(a, d, s), li = maxLevelIndex(e, a, d, s, cap);
            sp[i] = li < 0 ? -1 : product(e, a, d, s, li);
            if (li >= 0) any = true;
            order[i] = i;
        }
        if (!any) { RANKS.put(k, null); PRODUCTS.put(k, null); return; }
        Arrays.sort(order, (x, y) -> Double.compare(sp[y], sp[x]));
        int[] rank = new int[4096];
        for (int r = 0; r < 4096; r++) rank[order[r]] = sp[order[r]] < 0 ? 4096 : r + 1;
        RANKS.put(k, rank);
        PRODUCTS.put(k, new double[]{sp[order[0]]});
    }

    /** null if the Pokemon can't fit in the league at all. */
    public static Info info(PokeEntry e, int cap, int a, int d, int s) {
        build(e, cap);
        String k = e.id + ":" + cap;
        int[] rank = RANKS.get(k);
        if (rank == null) return null;
        int li = maxLevelIndex(e, a, d, s, cap);
        if (li < 0) return null;
        Info in = new Info();
        in.rank = rank[idx(a, d, s)];
        in.level = 1 + li * 0.5;
        in.cp = IvCalc.cp(e, a, d, s, in.level);
        in.pctOfBest = product(e, a, d, s, li) * 100 / PRODUCTS.get(k)[0];
        return in;
    }

    /** Best (lowest) and worst rank among candidate IV combos. {-1,-1} if not eligible. */
    public static int[] rankRange(PokeEntry e, int cap, List<IvCalc.Combo> combos) {
        int best = Integer.MAX_VALUE, worst = -1;
        Set<Integer> seen = new HashSet<>();
        for (IvCalc.Combo c : combos) {
            if (!seen.add(idx(c.a, c.d, c.s))) continue;
            Info in = info(e, cap, c.a, c.d, c.s);
            if (in == null) continue;
            best = Math.min(best, in.rank); worst = Math.max(worst, in.rank);
        }
        return worst < 0 ? new int[]{-1, -1} : new int[]{best, worst};
    }
}
